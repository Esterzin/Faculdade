
public class Principal {

    public static void main(String[] args) {
        FrmEquacao janela = new FrmEquacao();
        janela.setVisible(true);
    }
}
